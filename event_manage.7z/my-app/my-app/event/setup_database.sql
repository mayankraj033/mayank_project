CREATE DATABASE IF NOT EXISTS EventManagement;
USE EventManagement;

CREATE TABLE IF NOT EXISTS Venue (
    venue_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    capacity INT,
    location VARCHAR(200)
);

CREATE TABLE IF NOT EXISTS Event (
    event_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    date DATE NOT NULL,
    description TEXT,
    venue_id INT,
    FOREIGN KEY (venue_id) REFERENCES Venue(venue_id)
);

CREATE TABLE IF NOT EXISTS Participant (
    participant_id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    FOREIGN KEY (event_id) REFERENCES Event(event_id)
);

CREATE TABLE IF NOT EXISTS Schedule (
    schedule_id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT,
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    activity VARCHAR(200) NOT NULL,
    FOREIGN KEY (event_id) REFERENCES Event(event_id)
);

-- Insert sample venue
INSERT INTO Venue (name, capacity, location) 
VALUES ('Main Hall', 200, 'First Floor') 
ON DUPLICATE KEY UPDATE name=name; 