from a import app, init_db
import os

if __name__ == '__main__':
    # Initialize the database if it doesn't exist
    if not os.path.exists('event_management.db'):
        init_db()
    # Run the application
    app.run(host='127.0.0.1', port=5001, debug=True) 