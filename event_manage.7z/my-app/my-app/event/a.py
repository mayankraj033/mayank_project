from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)  # Enables frontend-backend interaction

# Database setup
DB_FILE = 'event_management.db'

def get_db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

# Initialize database
def init_db():
    conn = get_db()
    cursor = conn.cursor()
    
    # Create tables
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Venue (
            venue_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            capacity INTEGER,
            location TEXT
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Event (
            event_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            date DATE NOT NULL,
            description TEXT,
            venue_id INTEGER,
            FOREIGN KEY (venue_id) REFERENCES Venue(venue_id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Participant (
            participant_id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER,
            name TEXT NOT NULL,
            email TEXT,
            FOREIGN KEY (event_id) REFERENCES Event(event_id) ON DELETE CASCADE
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Schedule (
            schedule_id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER,
            start_time DATETIME NOT NULL,
            end_time DATETIME NOT NULL,
            activity TEXT NOT NULL,
            FOREIGN KEY (event_id) REFERENCES Event(event_id) ON DELETE CASCADE
        )
    ''')
    
    # Insert sample venues
    venues = [
        ('Main Hall', 200, 'First Floor'),
        ('Conference Room A', 50, 'Second Floor'),
        ('Grand Ballroom', 500, 'Ground Floor'),
        ('Meeting Room 101', 20, 'First Floor'),
        ('Outdoor Garden', 300, 'Ground Level'),
        ('Auditorium', 1000, 'Building B'),
        ('Workshop Space', 30, 'Third Floor'),
        ('Exhibition Hall', 400, 'Convention Center')
    ]
    
    cursor.execute('SELECT COUNT(*) FROM Venue')
    if cursor.fetchone()[0] == 0:
        cursor.executemany('INSERT INTO Venue (name, capacity, location) VALUES (?, ?, ?)', venues)
    
    conn.commit()
    conn.close()

@app.route('/')
def index():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Event")
    events = cursor.fetchall()
    conn.close()
    return render_template('index.html', events=events)

@app.route('/add_event', methods=['GET', 'POST'])
def add_event():
    conn = get_db()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        name = request.form['name']
        date = request.form['date']
        description = request.form['description']
        venue_id = request.form['venue_id']

        cursor.execute("INSERT INTO Event (name, date, description, venue_id) VALUES (?, ?, ?, ?)",
                      (name, date, description, venue_id))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))

    cursor.execute("SELECT * FROM Venue")
    venues = cursor.fetchall()
    conn.close()
    return render_template('add_event.html', venues=venues)

@app.route('/update_event/<int:event_id>', methods=['GET', 'POST'])
def update_event(event_id):
    conn = get_db()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        name = request.form['name']
        date = request.form['date']
        description = request.form['description']
        venue_id = request.form['venue_id']

        cursor.execute("UPDATE Event SET name = ?, date = ?, description = ?, venue_id = ? WHERE event_id = ?",
                      (name, date, description, venue_id, event_id))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))

    cursor.execute("SELECT * FROM Event WHERE event_id = ?", (event_id,))
    event = cursor.fetchone()
    cursor.execute("SELECT * FROM Venue")
    venues = cursor.fetchall()
    conn.close()
    return render_template('update_event.html', event=event, venues=venues)

@app.route('/delete_event/<int:event_id>')
def delete_event(event_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Event WHERE event_id = ?", (event_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/participants/<int:event_id>')
def participants(event_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Participant WHERE event_id = ?", (event_id,))
    participants = cursor.fetchall()
    conn.close()
    return render_template('participants.html', participants=participants, event_id=event_id)

@app.route('/add_participant/<int:event_id>', methods=['POST'])
def add_participant(event_id):
    if request.method == 'POST':
        conn = get_db()
        cursor = conn.cursor()
        
        name = request.form['name']
        email = request.form['email']
        
        cursor.execute("INSERT INTO Participant (event_id, name, email) VALUES (?, ?, ?)",
                      (event_id, name, email))
        conn.commit()
        conn.close()
        
    return redirect(url_for('participants', event_id=event_id))

@app.route('/delete_participant/<int:event_id>/<int:participant_id>')
def delete_participant(event_id, participant_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Participant WHERE participant_id = ? AND event_id = ?", 
                  (participant_id, event_id))
    conn.commit()
    conn.close()
    return redirect(url_for('participants', event_id=event_id))

@app.route('/schedule/<int:event_id>', methods=['GET', 'POST'])
def schedule(event_id):
    conn = get_db()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        start_time = request.form['start_time']
        end_time = request.form['end_time']
        activity = request.form['activity']

        cursor.execute("INSERT INTO Schedule (event_id, start_time, end_time, activity) VALUES (?, ?, ?, ?)",
                      (event_id, start_time, end_time, activity))
        conn.commit()
        conn.close()
        return redirect(url_for('schedule', event_id=event_id))

    cursor.execute("SELECT * FROM Schedule WHERE event_id = ?", (event_id,))
    schedule = cursor.fetchall()
    conn.close()
    return render_template('schedule.html', schedule=schedule, event_id=event_id)

if __name__ == '__main__':
    # Initialize the database before running the app
    if not os.path.exists(DB_FILE):
        init_db()
    app.run(debug=True, port=5000)