#!/bin/bash

while true; do
    clear
    echo "=== Events Monitor ==="
    echo "----------------------------------------"
    sqlite3 event_management.db <<EOF
.mode column
.headers on
SELECT 
    e.event_id, 
    e.name as event_name, 
    e.date, 
    v.name as venue,
    (SELECT COUNT(*) FROM Participant p WHERE p.event_id = e.event_id) as participants
FROM Event e 
LEFT JOIN Venue v ON e.venue_id = v.venue_id;
EOF

    echo -e "\n=== Participants Monitor ==="
    echo "----------------------------------------"
    sqlite3 event_management.db <<EOF
.mode column
.headers on
SELECT 
    p.participant_id,
    e.name as event_name,
    p.name as participant_name,
    p.email
FROM Participant p 
JOIN Event e ON p.event_id = e.event_id;
EOF

    echo -e "\n=== Schedule Monitor ==="
    echo "----------------------------------------"
    sqlite3 event_management.db <<EOF
.mode column
.headers on
SELECT 
    s.schedule_id,
    e.name as event_name,
    s.start_time,
    s.end_time,
    s.activity
FROM Schedule s 
JOIN Event e ON s.event_id = e.event_id;
EOF

    sleep 2
done 